﻿#!/usr/bin/env node
import { createHash, randomUUID } from "node:crypto";
import { mkdir, readFile, writeFile, stat } from "node:fs/promises";
import { existsSync } from "node:fs";
import { join, resolve } from "node:path";

const root = process.cwd();
const configPath = join(root, "velora-nas-agent.config.json");
const examplePath = join(root, "velora-nas-agent.config.example.json");
const config = JSON.parse(await readFile(existsSync(configPath) ? configPath : examplePath, "utf8"));
const storageRoot = resolve(root, config.storageRoot ?? "./data");
await mkdir(storageRoot, { recursive: true });
const identityPath = join(storageRoot, "nas-identity.json");
let identity;
if (existsSync(identityPath)) {
  identity = JSON.parse(await readFile(identityPath, "utf8"));
} else {
  identity = { nasId: `velora_nas_${randomUUID()}`, createdAt: new Date().toISOString() };
  await writeFile(identityPath, JSON.stringify(identity, null, 2));
}
const heartbeat = {
  ok: true,
  agent: config.agentName,
  version: config.version,
  mode: config.mode,
  nasIdHash: createHash("sha256").update(identity.nasId).digest("hex").slice(0, 24),
  storageRoot,
  forbiddenCapabilities: config.forbiddenCapabilities,
  checkedAt: new Date().toISOString()
};
await stat(storageRoot);
await writeFile(join(storageRoot, "last-health.json"), JSON.stringify(heartbeat, null, 2));
console.log(JSON.stringify(heartbeat, null, 2));
